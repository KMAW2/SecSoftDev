from flask import Flask, request, render_template, redirect, url_for
import psycopg2

app = Flask(__name__)

def create_table(): #chat log table creation
    try:
        con = psycopg2.connect(host='db', dbname='Chat', user='kmaw', password='1234')
        cursor = con.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                message TEXT NOT NULL
            );
        ''')
        
        con.commit()
        cursor.close()
        con.close()
        print("Table 'chat' created successfully.")
    except psycopg2.Error as e:
        print(f"Error creating table: {e}")

create_table()

@app.route('/')  # just '/' is main page
def main():
    return "[Main page]"

@app.route('/about')  # write plus "/about" to our URL
def about():
    return "[About page]"

@app.route('/login1', methods=["POST", "GET"])
def login_1():
    if request.method == "POST":
        user = request.form.get("nm")  # we take text from place where 'nm' stands in html
        message = request.form.get("msg")  # we take text from place where 'msg' stands in html
        
        return redirect(url_for("user", usr=user, msg=message))  # call for user func with arguments
    else:
        return render_template("login.html")  # at starting GET-request we take file from folder "templates" to be a main form to fill in username and message 

@app.route("/<usr>/<msg>")  # function for POST request
def user(usr, msg):
    con = psycopg2.connect(host='db', dbname='Chat', user='kmaw', password='1234')
    cursor = con.cursor()
    
    cursor.execute(f"INSERT INTO chat (name, message) VALUES ('{usr}', '{msg}')")
    con.commit()
    
    cursor.execute('SELECT name, message FROM chat')
    res = cursor.fetchall()

    cursor.close()
    con.close()
    return render_template("messages.html", query=res)

if __name__ == "__main__":
    app.run(host='0.0.0.0')
